lista =[]
lista.append(2)
lista.append(4)
lista.append(3)
print lista
lista.sort()
print lista
t = lista [1]
print t

i = len(lista)
for j in range (i):
	print lista[j]